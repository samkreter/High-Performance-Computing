#Homework 0
Just a simple parser and to get back up to date with c++

#Getting Started

1. create a directory called _build and generate the cmake files

    `$ mkdir _build; cd _build; cmake ..`

2. Run the make command to compile the files for your system

    `$ make`

3. Run the executable "runner" and enter the file to parse

    `$ ./runner`